
=============
django-mailer
=============

Contents:

.. toctree::

    usage
